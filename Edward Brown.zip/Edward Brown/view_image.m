function view_image(image)
    image = reshape(image, 28, 28);
    imshow(image)
end
